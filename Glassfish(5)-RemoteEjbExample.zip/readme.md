RemoteEjb on glassfish(5) example.
See this question on stackoverflow:
https://stackoverflow.com/questions/61098925/how-to-connect-to-remote-ejb-that-deployed-on-glassfish-from-java-se